import java.sql.SQLException;

import MLN.*;
public class Export {
	public static void main(String[] args){
		
		Exporter.setConnection("jdbc:mysql://kripke.cs.sfu.ca:3306/");
		Exporter.setSchema("unielwin");
		try {
			Exporter.ExportBN();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
