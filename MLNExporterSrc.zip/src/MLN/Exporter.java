package MLN;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
public class Exporter {
	public static String Connection = "jdbc:mysql://kripke.cs.sfu.ca:3306/";
	public static String Schema = "unielwin";
	public static void ExportBN() throws SQLException{
		Connection con = null;
		
		con = mySQLConnector.Connect("jdbc:mysql://kripke.cs.sfu.ca:3306/unielwin" , "sfu","joinBayes");
		System.out.println(con.getSchema());
		con.setSchema("unielwin");
		System.out.println(con.getSchema());
		Exporter.strBuilder(con);
	}
	
	public static void setConnection(String connection) {
		Connection = connection;
	}

	public static void setSchema(String schema) {
		Schema = schema;
	}

	public static String headerBuilder(Connection con){
		String header = "";
		ResultSet tables = null;
		ResultSet keys = null;
		ResultSet vars = null;
		Statement stmt = null;
		String[] tbList = null;
		String[] pKeys = null;
		
		
		try{
			PrintWriter writer = new PrintWriter(new FileOutputStream( new File(Schema + ".mln"), true));
			stmt = con.createStatement();
			if(stmt.execute("SHOW TABLES")){
				tables = stmt.getResultSet();
			}
			tbList = new String[GetSize(tables)];
//			System.out.println(tables.getRow());
			for(int i = 0; i < 5; i++){
				tables.previous();
				tbList[i] = tables.getString(1);
//				if(stmt.execute("SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='unielwin' AND `TABLE_NAME`='" + tables.getString(1) + "'")){
//					vars = stmt.getResultSet();
//				}
//				vars.next();
//				String key = vars.getNString(1);
//				System.out.printf("%s(%s_type)%n", key, key);
//				while(vars.next()){
//					String varName = vars.getString(1);
//					System.out.printf("%s(%s_type,%s_type)%n", key, key, varName);
//				}
			}
			MergeSort.mSort(tbList, 0, tbList.length - 1);
			for(int i = 0; i < tbList.length; i++){
				if(stmt.execute("SHOW KEYS FROM " + tbList[i] + " WHERE KEY_NAME = 'PRIMARY'"))
					keys = stmt.getResultSet();
					pKeys = new String[GetSize(keys)];
					for(int j = 0; keys.previous(); j++){
						
						pKeys[j] = keys.getString("COLUMN_NAME");
						
					}
					MergeSort.mSort(pKeys, 0, pKeys.length - 1);
					if(stmt.execute("SELECT column_name FROM information_schema.COLUMNS WHERE table_name = '" + tbList[i] + "' and table_schema = 'unielwin'")){
						vars = stmt.getResultSet();
					}
					if(pKeys.length == 1){
						header += pKeys[0] + "(" + pKeys[0] + "_type)\n";
						}
					else{
						header += "B_" + tbList[i] + "(" + pKeys[0] + "_type";
						for(int j = 1; j < pKeys.length; j++){
								header += "," + pKeys[j] + "_type";
						}
						header+= ")\n";
					}
					while (vars.next()){
						boolean isPKey = false;
						for(int j = 0;  j < pKeys.length; j++){
							if(vars.getString("column_name").compareTo(pKeys[j]) == 0)
								isPKey = true;
						}
						if(!isPKey){
							header += vars.getString("column_name") + "(";
							header += pKeys[0] + "_type";
							for(int j = 1; j < pKeys.length; j++){
								header += "," + pKeys[j] + "_type";
							}
							header += "," + vars.getString(1) + "_type";
							if(pKeys.length == 1)
								header += "!";
							header += ")\n";
						}
						
							
					}

			}
			writer.printf("%s%n", header);
			writer.flush();
			writer.close();
		}
		catch(SQLException ex){
			System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			if (tables != null) {
		        try {
		        	tables.close();
		        } catch (SQLException sqlEx) { } // ignore
		    }
			if (keys != null) {
		        try {
		        	keys.close();
		        } catch (SQLException sqlEx) { } // ignore
		    }
			if (vars != null) {
		        try {
		        	vars.close();
		        } catch (SQLException sqlEx) { } // ignore
		    }
			
		    
		    
		}
		
		return header;
	}
	public static int getNNode(String N, Connection con, BNNode[] nodes, int counter) throws SQLException{
		
		ResultSet temp = null;
		String t = "";
		String MLNStr = "";
		String ID = "";
		String BNSchema = Schema + "_BN";
		con.setSchema(BNSchema);//change current schema to the corresponding BN schema
		Statement stmt = con.createStatement();
		
	
		stmt.execute("SELECT * FROM " + BNSchema + "." + N + "Nodes");
		temp = stmt.getResultSet();
		while(temp.next()){
			ID = "";
			MLNStr = "";
			t = temp.getString(N + "nid").substring(1);
			t = t.substring(0, t.length() - 1);
			int last = 0;
			
			for(int i = 0; i < t.length(); i++){
				if(t.charAt(i) == ',' || t.charAt(i) == ')'){
					MLNStr += t.substring(last, i - 1);
					MLNStr += "_id_inst";
					last = i;
				}
			}
			MLNStr += "," + temp.getString("COLUMN_NAME").toUpperCase() + "_";
			ID = temp.getString(N + "nid").substring(1);
			ID = ID.substring(0, ID.length() - 1);
			nodes[counter] = new BNNode(temp.getString("COLUMN_NAME"), ID, MLNStr, false);
			counter++;
			System.out.println(MLNStr);
		}		
		return counter;
			
	}
	public static void bodyBuilder(Connection con){
		try {
			PrintWriter writer = new PrintWriter(new FileOutputStream( new File(Schema + ".mln"), true));
			ResultSet temp = null;
			BNNode[] nodes = null;
			BNNode[] columnNames= null;
			String t = "";
			String table = "";
			String line = "";
			String MLNStr = "";
			String ID = "";
			int counter = 0;
			int complement = 0;
			String BNSchema = Schema + "_BN";
			con.setSchema(BNSchema);//change current schema to the corresponding BN schema
			Statement stmt = con.createStatement();
			stmt.execute("SELECT * FROM " + BNSchema + ".NumAttributes");
			nodes = new BNNode[GetSize(stmt.getResultSet())];
			stmt.execute("SELECT * FROM " + BNSchema + ".RNodes");
			temp = stmt.getResultSet();
			while(temp.next()){
				ID = "";
				MLNStr = "B_";
				t = temp.getString("orig_rnid").substring(1);
				t = t.substring(0, t.length() - 1);
				int last = 0;
				
				for(int i = 0; i < t.length(); i++){
					if(t.charAt(i) == ',' || t.charAt(i) == ')'){
						MLNStr += t.substring(last, i - 1);
						MLNStr += "_id_inst";
						last = i;
					}
				}
				MLNStr += ")";
				ID = temp.getString("rnid").substring(1);
				ID = ID.substring(0, ID.length() - 1);
				nodes[counter] = new BNNode(temp.getString("TABLE_NAME"), ID, MLNStr, true);
				counter++;
			}
			
			for(int i = 1; nodes[nodes.length - 1] == null; i++){
				counter = getNNode(new Integer(i).toString(), con, nodes, counter);
			}
			
			for (int i = 0; i < nodes.length; i++)
			{
				String CP_tablename = nodes[i].getID() + "_CP";
//				stmt.execute("SELECT * FROM " + BNSchema + "." + CP_tablename);
//				temp = stmt.getResultSet();
				stmt.execute("SELECT column_name FROM information_schema.COLUMNS WHERE table_name = '" + CP_tablename + "' and table_schema = '" + BNSchema + "'");
				temp = stmt.getResultSet();
				counter = 0;
				complement = 0;
				while(temp.next()){
					complement += 1;;
					if(temp.getString("column_name").compareTo("ChildValue") == 0){
						counter++;
						break;
					}
				}
				while(temp.next() && temp.getString("column_name" ).compareTo("ParentSum") != 0 && temp.getString("column_name" ).compareTo("CP") != 0){
					counter ++;
				}
				columnNames = new BNNode[counter];
				columnNames[0] = nodes[i];
				while(temp.previous() && counter != 1){
					for(int j = 0; j < nodes.length; j++){
						if(temp.getString(1).compareTo(nodes[j].getID()) == 0){
							columnNames[counter - 1] = nodes[j];
							break;
						}
					}
					counter--;
				}
				stmt.execute("SELECT * FROM " + BNSchema + ".`"+ CP_tablename +"`");
				temp = stmt.getResultSet();
				while(temp.next()){
					 for(int k = 0; k < columnNames.length; k++){
						 if(columnNames[k].isR()){
							 if(temp.getString(complement + k).compareTo("F") == 0){
								 if(k >= 1){
									 if(temp.getString(complement + k - 1).compareTo("N/A") != 0){
										 line += ("!" + columnNames[k].getMLNStr());
									 }
									 else{
										 line = "";
										 break;
									 }
								 }
								 else{
									 if(complement + k + 1 == columnNames.length){
										 line += "!" + columnNames[k].getMLNStr();
									 }
									 else if(temp.getString(complement + k + 1).compareTo("N/A") != 0){
										 line += "!" + columnNames[k].getMLNStr();
									 }
									 else{
										 line = "";
										 break;
									 }
								 }
							 }
							 else{
								 line += columnNames[k].getMLNStr();
							 }
						
						
						 }
						 else{
								line += columnNames[k].getMLNStr() + temp.getString(complement + k) +")";
							}
						 if(k != columnNames.length - 1)
							 line+=" ^ ";
						 
							 
					 }
					 if(line.compareTo("") != 0)
						line += "\n";
					 table += line;
					 line = "";
					 
				}
				System.out.println(table);
				
				writer.print(table);
				writer.flush();
				table = "";
						
			}
			stmt.execute("SELECT * FROM " + BNSchema + ".Attribute_Value");
			temp = stmt.getResultSet();
			line = "";
			table = "";
			while(temp.next()){
				for(int i = 0; i < nodes.length; i++){
					if(nodes[i].isR()){
						if(temp.getString("COLUMN_NAME").compareTo("`" + nodes[i].getID() + "`") == 0){
							if(temp.getString("VALUE") == "False")
								line += "!" + nodes[i].getMLNStr();
							else
								line += nodes[i].getMLNStr();
							break;
						}
					}
					else{
						if(temp.getString("COLUMN_NAME").compareTo(nodes[i].getName()) == 0){
							line += nodes[i].getMLNStr() + temp.getString("VALUE") + ")";
						}
					}
				}
				line += "\n";
				table += line;
				line = "";
			}
			writer.printf("%s", table);
			writer.flush();
			writer.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * 
	 */
	public static void strBuilder(Connection con){
			System.out.printf("%s%n", headerBuilder(con));
			bodyBuilder(con);
			if (con != null) {
		        try {
		        	con.close();
		        } catch (SQLException sqlEx) { } // ignore
		    }
		}
		
	public static int GetSize(ResultSet result){
		int counter = 0;
		try{
			while(result.next())
			{
				counter++;
			}
		}
		catch(SQLException ex){
			System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		}		
		return counter;	
	}
	
}
