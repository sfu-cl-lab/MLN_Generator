package MLN;

public class MergeSort {
	public static void mSort(String[] array, int low, int high){
		if(low < high){
			int mid = (low + high) / 2;
			mSort(array, low, mid);
			mSort(array, mid + 1, high);
			merge(array, low, mid, mid + 1, high);
		}
		else
			return;
		
	}
	public static void merge(String[] array, int first1, int last1, int first2, int last2){
		String[] temp = new String[last2 - first1 + 1];
		int low = first1;
		int high = last2;
		int index = 0;
		for(; (first1 <= last1) && (first2 <= last2) ; index++){
			if(array[first1].toLowerCase().compareTo(array[first2].toLowerCase()) < 0){
				temp[index] = array[first1];
				first1 ++;
			}
			else{
				temp[index] = array[first2];
				first2 ++;
			}
		}
		
		for(;first1 <= last1; ++first1, ++index){
			temp[index] = array[first1];
		}
		for(;first2 <= last2; ++first2, ++index){
			temp[index] = array[first2];
		}
		
		index = 0;
		for(int i = low; i <= high; i++, index++){
			array[i] = temp[index];
		}
	}
}
