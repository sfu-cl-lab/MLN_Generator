package MLN;

public class BNNode {
	private String name;
	private String ID;
	private String MLNStr;
	private boolean isR;
	
	public String getName() {
		return name;
	}

	public String getID() {
		return ID;
	}

	public String getMLNStr() {
		return MLNStr;
	}

	public BNNode(String name, String ID, String MLNStr, boolean isR){
		this.name = name;
		this.ID = ID;
		this.MLNStr = MLNStr;
		this.isR = isR;
	}

	public boolean isR() {
		return isR;
	}
}
