package MLN;
import java.sql.*;
public class mySQLConnector {
	public static Connection Connect(String server, String usr, String pw){
		Connection con = null;
		Statement stmt = null; 
		ResultSet result = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception ex){
			System.out.println("ERROR!");
			return null;
		}
		try{
			con = DriverManager.getConnection(server, usr, pw);
//			stmt = con.createStatement();
//			if (stmt.execute("SELECT ranking FROM student")) {
//		        result = stmt.getResultSet();
//		    }
//			while(result.next()){
//				System.out.printf("%-10d %n",result.getInt(1));
//			}
		}
		catch(SQLException ex){
			System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		    return null;
		}
		
		finally {
		    // it is a good idea to release
		    // resources in a finally{} block
		    // in reverse-order of their creation
		    // if they are no-longer needed
		    if (result != null) {
		        try {
		            result.close();
		        } catch (SQLException sqlEx) { } // ignore
		        result = null;
		    }
		    if (stmt != null) {
		        try {
		            stmt.close();
		        } catch (SQLException sqlEx) { } // ignore
		        stmt = null;
		    }
		    
		}
		return con;
	}
	
	public static ResultSet Execute(String query, Connection con){
		Statement stmt = null;
		ResultSet result = null;
		try{
			stmt = con.createStatement();
			if(stmt.execute(query)){
				result = stmt.getResultSet();
			}
			
			
		}
		catch(SQLException ex){
			System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		}
		
		finally {
		    
		    if (stmt != null) {
		        try {
		            stmt.close();
		        } catch (SQLException sqlEx) { } // ignore
		        stmt = null;
		    }
		    
		}
		return result;
	}
}
